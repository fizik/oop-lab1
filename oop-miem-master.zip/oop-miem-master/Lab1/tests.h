#ifndef TESTS_H
#define TESTS_H

void testLamps();
#endif // TESTS_H
